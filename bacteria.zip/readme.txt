This file contains archived directories that correspond to each type of bacteria. 
The directory contains the consensus sequence in png format and a file with multiple 
alignment in fasta format of the found sequences for the analyzed bacterial genome. 
The name of the bacterium is given in Table 1
